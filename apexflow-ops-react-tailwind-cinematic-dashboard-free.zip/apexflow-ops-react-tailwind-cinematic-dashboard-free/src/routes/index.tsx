import { createFileRoute } from "@tanstack/react-router";
import { ApexApp } from "@/components/apex/App";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ApexOps — Work-Package & Operations Tracker" },
      {
        name: "description",
        content:
          "Premium operations control center for industrial work-package tracking, cost optimization, and compliance document management.",
      },
      { property: "og:title", content: "ApexOps — Work-Package & Operations Tracker" },
      {
        property: "og:description",
        content:
          "Dark-mode enterprise dashboard for turnaround, cost, and compliance operations.",
      },
    ],
  }),
  component: Index,
});

function Index() {
  return <ApexApp />;
}
