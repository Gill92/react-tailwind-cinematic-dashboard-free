import { useMemo, useState } from "react";
import { DragDropContext, Droppable, Draggable, type DropResult } from "@hello-pangea/dnd";
import {
  Search,
  Plus,
  SlidersHorizontal,
  Calendar,
  MoreHorizontal,
  Eye,
  ArrowRightLeft,
  GaugeCircle,
  Lock,
} from "lucide-react";
import {
  workPackages as seed,
  STATUS_LABELS,
  type WorkPackage,
  type PackageStatus,
} from "@/lib/mockData";
import { useApp } from "./context";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Slider } from "@/components/ui/slider";
import { toast } from "sonner";

const columns: PackageStatus[] = ["scope", "in-progress", "verification", "complete"];

const priorityBar: Record<WorkPackage["priority"], string> = {
  "on-track": "bg-emerald-500",
  watch: "bg-amber-500",
  "at-risk": "bg-red-500",
};

function currency(n: number) {
  if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(2)}M`;
  return `$${Math.round(n / 1000)}K`;
}

type DialogMode = "details" | "status" | "progress";

export function WorkPackagesView() {
  const { viewMode } = useApp();
  const isClient = viewMode === "client";
  const [items, setItems] = useState<WorkPackage[]>(seed);
  const [q, setQ] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [mode, setMode] = useState<DialogMode>("details");
  const [draftStatus, setDraftStatus] = useState<PackageStatus>("scope");
  const [draftProgress, setDraftProgress] = useState<number>(0);

  const active = useMemo(
    () => items.find((p) => p.id === activeId) ?? null,
    [items, activeId],
  );

  const filtered = useMemo(() => {
    let list = items;
    if (isClient) list = list.filter((p) => p.clientVisible);
    if (q.trim()) {
      const s = q.toLowerCase();
      list = list.filter(
        (p) => p.title.toLowerCase().includes(s) || p.code.toLowerCase().includes(s),
      );
    }
    return list;
  }, [items, isClient, q]);

  const byCol = useMemo(() => {
    const map: Record<PackageStatus, WorkPackage[]> = {
      scope: [],
      "in-progress": [],
      verification: [],
      complete: [],
    };
    filtered.forEach((p) => map[p.status].push(p));
    return map;
  }, [filtered]);

  const onDragEnd = (r: DropResult) => {
    if (!r.destination) return;
    if (isClient) {
      toast.error("Read-only view", {
        description: "Client mode cannot reorder work packages.",
      });
      return;
    }
    const dest = r.destination.droppableId as PackageStatus;
    const id = r.draggableId;
    setItems((prev) => prev.map((p) => (p.id === id ? { ...p, status: dest } : p)));
  };

  const openAction = (p: WorkPackage, m: DialogMode) => {
    setActiveId(p.id);
    setMode(m);
    setDraftStatus(p.status);
    setDraftProgress(p.progress);
  };

  const closeDialog = () => setActiveId(null);

  const commitStatus = () => {
    if (!active) return;
    setItems((prev) =>
      prev.map((p) => (p.id === active.id ? { ...p, status: draftStatus } : p)),
    );
    toast.success(`Package ${active.code} moved`, {
      description: `Now in ${STATUS_LABELS[draftStatus]}.`,
    });
    closeDialog();
  };

  const commitProgress = () => {
    if (!active) return;
    const next = Math.max(0, Math.min(100, Math.round(draftProgress)));
    setItems((prev) =>
      prev.map((p) =>
        p.id === active.id
          ? { ...p, progress: next, status: next === 100 ? "complete" : p.status }
          : p,
      ),
    );
    toast.success(`Package ${active.code} updated`, {
      description: `Progress set to ${next}%.`,
    });
    closeDialog();
  };

  return (
    <div className="space-y-6">
      {/* Toolbar */}
      <div className="flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search packages, codes, sites…"
            className="w-full h-10 pl-9 pr-3 rounded-lg bg-surface border border-border text-[13px] text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/40 focus:ring-1 focus:ring-emerald-500/30 transition-all"
          />
        </div>
        <button className="inline-flex items-center gap-2 h-10 px-3 rounded-lg bg-surface border border-border text-[13px] text-slate-300 hover:bg-surface-hover transition-all">
          <SlidersHorizontal className="h-4 w-4" />
          Filter
        </button>
        <button className="inline-flex items-center gap-2 h-10 px-3 rounded-lg bg-surface border border-border text-[13px] text-slate-300 hover:bg-surface-hover transition-all">
          <Calendar className="h-4 w-4" />
          This Quarter
        </button>
        <div className="flex-1" />
        {isClient ? (
          <div className="inline-flex items-center gap-2 h-10 px-3 rounded-lg bg-surface border border-border text-[12px] text-slate-400">
            <Lock className="h-3.5 w-3.5" />
            Read-only client view
          </div>
        ) : (
          <button className="inline-flex items-center gap-2 h-10 px-4 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-emerald-950 text-[13px] font-semibold transition-all shadow-lg shadow-emerald-500/20">
            <Plus className="h-4 w-4" strokeWidth={2.5} />
            New Work Package
          </button>
        )}
      </div>

      {/* Board */}
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
          {columns.map((col) => (
            <Droppable droppableId={col} key={col} isDropDisabled={isClient}>
              {(prov, snap) => (
                <div
                  className={`rounded-xl bg-surface/60 border border-border p-3 transition-colors ${
                    snap.isDraggingOver ? "border-emerald-500/40 bg-emerald-500/5" : ""
                  }`}
                >
                  <div className="flex items-center justify-between px-2 pt-1 pb-3">
                    <div className="flex items-center gap-2">
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${
                          col === "complete"
                            ? "bg-emerald-500"
                            : col === "verification"
                              ? "bg-sky-500"
                              : col === "in-progress"
                                ? "bg-amber-500"
                                : "bg-slate-500"
                        }`}
                      />
                      <h4 className="text-[12.5px] font-semibold tracking-tight text-slate-200">
                        {STATUS_LABELS[col]}
                      </h4>
                    </div>
                    <span className="tabular text-[11px] font-medium text-slate-400 rounded-md px-1.5 py-0.5 bg-surface-hover border border-border">
                      {byCol[col].length}
                    </span>
                  </div>
                  <div
                    ref={prov.innerRef}
                    {...prov.droppableProps}
                    className="space-y-3 min-h-[80px]"
                  >
                    {byCol[col].map((p, idx) => (
                      <Draggable
                        key={p.id}
                        draggableId={p.id}
                        index={idx}
                        isDragDisabled={isClient}
                      >
                        {(dp, dsnap) => (
                          <div
                            ref={dp.innerRef}
                            {...dp.draggableProps}
                            {...dp.dragHandleProps}
                            className={`group relative overflow-hidden rounded-lg bg-surface border border-border p-4 transition-all duration-200 hover:border-slate-700 ${
                              dsnap.isDragging
                                ? "shadow-2xl shadow-black/60 ring-1 ring-emerald-500/40 rotate-[0.5deg]"
                                : ""
                            }`}
                          >
                            <span
                              className={`absolute left-0 top-0 bottom-0 w-[3px] ${priorityBar[p.priority]}`}
                            />
                            <div className="flex items-start justify-between gap-2">
                              <div className="min-w-0">
                                <div className="text-[10.5px] font-medium uppercase tracking-widest text-slate-500">
                                  Package {p.code}
                                </div>
                                <div className="mt-1 text-[13.5px] font-semibold text-slate-100 leading-snug">
                                  {p.title}
                                </div>
                              </div>

                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <button
                                    aria-label="Quick actions"
                                    onClick={(e) => e.stopPropagation()}
                                    className="shrink-0 h-7 w-7 grid place-items-center rounded-md text-slate-500 hover:text-slate-100 hover:bg-surface-hover border border-transparent hover:border-border opacity-70 group-hover:opacity-100 transition-all"
                                  >
                                    <MoreHorizontal className="h-4 w-4" />
                                  </button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent
                                  align="end"
                                  className="w-56 bg-surface border-border text-slate-200"
                                >
                                  <DropdownMenuLabel className="text-[10.5px] uppercase tracking-widest text-slate-500 font-medium">
                                    Package {p.code}
                                  </DropdownMenuLabel>
                                  <DropdownMenuSeparator className="bg-border" />
                                  <DropdownMenuItem
                                    onClick={() => openAction(p, "details")}
                                    className="gap-2 focus:bg-surface-hover focus:text-slate-100"
                                  >
                                    <Eye className="h-4 w-4 text-slate-400" />
                                    View details
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    disabled={isClient}
                                    onClick={() => openAction(p, "status")}
                                    className="gap-2 focus:bg-surface-hover focus:text-slate-100"
                                  >
                                    <ArrowRightLeft className="h-4 w-4 text-slate-400" />
                                    Update status
                                    {isClient && (
                                      <Lock className="ml-auto h-3 w-3 text-slate-500" />
                                    )}
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    disabled={isClient}
                                    onClick={() => openAction(p, "progress")}
                                    className="gap-2 focus:bg-surface-hover focus:text-slate-100"
                                  >
                                    <GaugeCircle className="h-4 w-4 text-slate-400" />
                                    Edit progress
                                    {isClient && (
                                      <Lock className="ml-auto h-3 w-3 text-slate-500" />
                                    )}
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </div>
                            <div className="mt-2 text-[11.5px] text-slate-400">
                              {p.site} · {p.clientName}
                            </div>

                            {/* Progress */}
                            <div className="mt-3">
                              <div className="flex items-center justify-between text-[11px] text-slate-500 mb-1">
                                <span>Progress</span>
                                <span className="tabular text-slate-300 font-medium">
                                  {p.progress}%
                                </span>
                              </div>
                              <div className="h-1.5 rounded-full bg-surface-hover overflow-hidden">
                                <div
                                  className={`h-full ${
                                    p.priority === "at-risk"
                                      ? "bg-red-500"
                                      : p.priority === "watch"
                                        ? "bg-amber-500"
                                        : "bg-emerald-500"
                                  }`}
                                  style={{ width: `${p.progress}%` }}
                                />
                              </div>
                            </div>

                            {/* Footer row */}
                            <div className="mt-4 flex items-center justify-between gap-2">
                              {!isClient ? (
                                <div className="flex items-center gap-2 min-w-0">
                                  <div className="h-6 w-6 shrink-0 rounded-full bg-slate-700 grid place-items-center text-[10px] font-semibold text-slate-100 ring-1 ring-slate-600">
                                    {p.leadInitials}
                                  </div>
                                  <div className="text-[11.5px] text-slate-400 truncate">
                                    {p.lead}
                                  </div>
                                </div>
                              ) : (
                                <div className="text-[11.5px] text-slate-500">
                                  Due {p.dueDate}
                                </div>
                              )}
                              {!isClient ? (
                                <span
                                  className={`shrink-0 tabular text-[11px] font-medium rounded-md px-2 py-0.5 ring-1 ring-inset ${
                                    p.actualCost > p.budget
                                      ? "text-red-400 bg-red-500/10 ring-red-500/20"
                                      : "text-slate-300 bg-surface-hover ring-border"
                                  }`}
                                >
                                  {currency(p.actualCost)} / {currency(p.budget)}
                                </span>
                              ) : (
                                <span className="shrink-0 text-[11px] font-medium text-slate-300 rounded-md px-2 py-0.5 bg-surface-hover ring-1 ring-inset ring-border">
                                  {p.progress === 100 ? "Delivered" : "In-flight"}
                                </span>
                              )}
                            </div>

                            {!isClient && (
                              <div className="mt-2 text-[11px] text-slate-500 tabular">
                                Due {p.dueDate}
                              </div>
                            )}
                          </div>
                        )}
                      </Draggable>
                    ))}
                    {prov.placeholder}
                  </div>
                </div>
              )}
            </Droppable>
          ))}
        </div>
      </DragDropContext>

      {/* Quick-action dialog */}
      <Dialog open={!!active} onOpenChange={(o) => !o && closeDialog()}>
        <DialogContent className="bg-surface border-border text-slate-100 max-w-lg">
          {active && mode === "details" && (
            <>
              <DialogHeader>
                <div className="text-[10.5px] font-medium uppercase tracking-widest text-slate-500">
                  Package {active.code}
                </div>
                <DialogTitle className="text-slate-100 text-lg leading-snug">
                  {active.title}
                </DialogTitle>
                <DialogDescription className="text-slate-400">
                  {active.site} · {active.clientName}
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-3 mt-2 text-[12.5px]">
                <Field label="Status" value={STATUS_LABELS[active.status]} />
                <Field label="Priority" value={active.priority} />
                <Field label="Progress" value={`${active.progress}%`} />
                <Field label="Due" value={active.dueDate} />
                {!isClient && (
                  <>
                    <Field label="Lead" value={active.lead} />
                    <Field
                      label="Budget / Actual"
                      value={`${currency(active.actualCost)} / ${currency(active.budget)}`}
                      tone={active.actualCost > active.budget ? "danger" : "default"}
                    />
                  </>
                )}
              </div>
              {isClient && (
                <div className="mt-3 flex items-center gap-2 text-[11.5px] text-slate-500 rounded-md border border-border bg-surface-hover/50 px-3 py-2">
                  <Lock className="h-3.5 w-3.5" />
                  Cost & assignment details restricted in client view.
                </div>
              )}
              <DialogFooter>
                <button
                  onClick={closeDialog}
                  className="h-9 px-3 rounded-md bg-surface-hover border border-border text-[12.5px] text-slate-200 hover:border-slate-600"
                >
                  Close
                </button>
              </DialogFooter>
            </>
          )}

          {active && mode === "status" && !isClient && (
            <>
              <DialogHeader>
                <DialogTitle className="text-slate-100">
                  Update status — {active.code}
                </DialogTitle>
                <DialogDescription className="text-slate-400">
                  Move this package to a different workflow column.
                </DialogDescription>
              </DialogHeader>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {columns.map((c) => (
                  <button
                    key={c}
                    onClick={() => setDraftStatus(c)}
                    className={`text-left px-3 py-2 rounded-md border text-[12.5px] transition-all ${
                      draftStatus === c
                        ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-200"
                        : "border-border bg-surface-hover/40 text-slate-300 hover:border-slate-600"
                    }`}
                  >
                    {STATUS_LABELS[c]}
                  </button>
                ))}
              </div>
              <DialogFooter>
                <button
                  onClick={closeDialog}
                  className="h-9 px-3 rounded-md bg-surface-hover border border-border text-[12.5px] text-slate-200 hover:border-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={commitStatus}
                  className="h-9 px-4 rounded-md bg-emerald-500 hover:bg-emerald-400 text-emerald-950 text-[12.5px] font-semibold"
                >
                  Save
                </button>
              </DialogFooter>
            </>
          )}

          {active && mode === "progress" && !isClient && (
            <>
              <DialogHeader>
                <DialogTitle className="text-slate-100">
                  Edit progress — {active.code}
                </DialogTitle>
                <DialogDescription className="text-slate-400">
                  Setting progress to 100% will mark this package as Sign-Off Complete.
                </DialogDescription>
              </DialogHeader>
              <div className="mt-2 space-y-4">
                <div className="flex items-baseline justify-between">
                  <span className="text-[11.5px] uppercase tracking-widest text-slate-500">
                    Completion
                  </span>
                  <span className="tabular text-2xl font-semibold text-slate-100">
                    {Math.round(draftProgress)}%
                  </span>
                </div>
                <Slider
                  value={[draftProgress]}
                  min={0}
                  max={100}
                  step={1}
                  onValueChange={(v) => setDraftProgress(v[0] ?? 0)}
                />
                <div className="h-1.5 rounded-full bg-surface-hover overflow-hidden">
                  <div
                    className="h-full bg-emerald-500 transition-all"
                    style={{ width: `${draftProgress}%` }}
                  />
                </div>
              </div>
              <DialogFooter>
                <button
                  onClick={closeDialog}
                  className="h-9 px-3 rounded-md bg-surface-hover border border-border text-[12.5px] text-slate-200 hover:border-slate-600"
                >
                  Cancel
                </button>
                <button
                  onClick={commitProgress}
                  className="h-9 px-4 rounded-md bg-emerald-500 hover:bg-emerald-400 text-emerald-950 text-[12.5px] font-semibold"
                >
                  Save
                </button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Field({
  label,
  value,
  tone = "default",
}: {
  label: string;
  value: string;
  tone?: "default" | "danger";
}) {
  return (
    <div className="rounded-md border border-border bg-surface-hover/40 px-3 py-2">
      <div className="text-[10.5px] uppercase tracking-widest text-slate-500 font-medium">
        {label}
      </div>
      <div
        className={`mt-0.5 text-[13px] font-medium capitalize ${
          tone === "danger" ? "text-red-400" : "text-slate-100"
        }`}
      >
        {value}
      </div>
    </div>
  );
}
