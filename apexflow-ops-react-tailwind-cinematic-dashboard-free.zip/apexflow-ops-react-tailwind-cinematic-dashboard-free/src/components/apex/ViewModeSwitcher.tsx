import { useApp } from "./context";

export function ViewModeSwitcher() {
  const { viewMode, setViewMode } = useApp();
  return (
    <div className="relative inline-flex items-center rounded-lg bg-surface-hover/70 ring-1 ring-inset ring-border p-1">
      <div
        className="absolute top-1 bottom-1 rounded-md bg-emerald-500/15 ring-1 ring-emerald-500/30 transition-all duration-300 ease-out"
        style={{
          width: "calc(50% - 4px)",
          left: viewMode === "operator" ? "4px" : "calc(50%)",
        }}
      />
      {(["operator", "client"] as const).map((m) => (
        <button
          key={m}
          onClick={() => setViewMode(m)}
          className={`relative z-10 px-4 py-1.5 text-[12.5px] font-medium tracking-tight transition-colors ${
            viewMode === m ? "text-emerald-300" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          {m === "operator" ? "Operator" : "Third-Party Client"}
        </button>
      ))}
    </div>
  );
}
