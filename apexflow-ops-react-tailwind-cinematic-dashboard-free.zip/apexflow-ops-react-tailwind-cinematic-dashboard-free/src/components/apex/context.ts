import { createContext, useContext } from "react";

export type ViewMode = "operator" | "client";
export type ViewKey = "overview" | "workpackages" | "analytics" | "vault";

export interface AppCtx {
  viewMode: ViewMode;
  setViewMode: (m: ViewMode) => void;
  view: ViewKey;
  setView: (v: ViewKey) => void;
}

export const AppContext = createContext<AppCtx | null>(null);

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("AppContext missing");
  return ctx;
}
