import { useMemo, useState } from "react";
import { Search, Download, Check, Loader2, FileText } from "lucide-react";
import { documents, type DocumentRow } from "@/lib/mockData";
import { StatusBadge } from "./StatusBadge";
import { useApp } from "./context";

const categories = ["All", "Specifications", "Compliance", "Invoices"] as const;
type Cat = (typeof categories)[number];

export function VaultView() {
  const { viewMode } = useApp();
  const [q, setQ] = useState("");
  const [cat, setCat] = useState<Cat>("All");
  const [dlState, setDlState] = useState<Record<string, "idle" | "loading" | "done">>({});

  const list = useMemo(() => {
    let docs: DocumentRow[] = documents;
    if (viewMode === "client") {
      docs = docs.filter((d) => d.clientVisible);
    }
    if (cat !== "All") docs = docs.filter((d) => d.category === cat);
    if (q.trim()) {
      const s = q.toLowerCase();
      docs = docs.filter((d) => d.name.toLowerCase().includes(s) || d.packageCode.includes(s));
    }
    return docs;
  }, [viewMode, cat, q]);

  const visibleCategories = useMemo(() => {
    if (viewMode === "client") return categories.filter((c) => c !== "Invoices");
    return categories;
  }, [viewMode]);

  const handleDownload = (id: string) => {
    setDlState((s) => ({ ...s, [id]: "loading" }));
    setTimeout(() => {
      setDlState((s) => ({ ...s, [id]: "done" }));
      setTimeout(() => setDlState((s) => ({ ...s, [id]: "idle" })), 1600);
    }, 500);
  };

  return (
    <div className="rounded-xl bg-surface border border-border overflow-hidden">
      {/* Toolbar */}
      <div className="p-5 border-b border-border flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[240px] max-w-md">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search documents…"
            className="w-full h-10 pl-9 pr-3 rounded-lg bg-background border border-border text-[13px] text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500/40 focus:ring-1 focus:ring-emerald-500/30 transition-all"
          />
        </div>
        <div className="flex items-center gap-1.5">
          {visibleCategories.map((c) => (
            <button
              key={c}
              onClick={() => setCat(c)}
              className={`h-9 px-3 rounded-lg text-[12.5px] font-medium transition-all ${
                cat === c
                  ? "bg-emerald-500/15 text-emerald-300 ring-1 ring-inset ring-emerald-500/30"
                  : "text-slate-400 hover:text-slate-100 hover:bg-surface-hover"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="flex-1" />
        <div className="text-[12px] text-slate-500 tabular">
          <span className="text-slate-300 font-medium">{list.length}</span> documents
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left">
          <thead>
            <tr className="text-[11px] uppercase tracking-widest text-slate-500 font-medium">
              <th className="px-6 py-3 font-medium">Document</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Package</th>
              <th className="px-4 py-3 font-medium">Uploaded</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Size</th>
              <th className="px-4 py-3 font-medium text-right">Action</th>
            </tr>
          </thead>
          <tbody>
            {list.map((d) => {
              const s = dlState[d.id] ?? "idle";
              return (
                <tr
                  key={d.id}
                  className="border-t border-border transition-colors hover:bg-surface-hover/50"
                >
                  <td className="px-6 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className="h-8 w-8 shrink-0 grid place-items-center rounded-md bg-surface-hover ring-1 ring-inset ring-border">
                        <FileText className="h-4 w-4 text-slate-400" />
                      </div>
                      <div className="text-[13.5px] text-slate-100 font-medium truncate max-w-[340px]">
                        {d.name}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className="inline-flex items-center rounded-md px-2 py-0.5 text-[11.5px] font-medium text-slate-300 bg-surface-hover ring-1 ring-inset ring-border">
                      {d.category}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-[13px] text-slate-300 tabular">{d.packageCode}</td>
                  <td className="px-4 py-3.5 text-[13px] text-slate-400 tabular">{d.uploaded}</td>
                  <td className="px-4 py-3.5">
                    <StatusBadge status={d.status} />
                  </td>
                  <td className="px-4 py-3.5 text-[13px] text-slate-400 tabular">{d.size}</td>
                  <td className="px-4 py-3.5 text-right">
                    <button
                      onClick={() => handleDownload(d.id)}
                      disabled={s !== "idle"}
                      className={`inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-[12px] font-medium transition-all ${
                        s === "done"
                          ? "text-emerald-300 bg-emerald-500/15 ring-1 ring-inset ring-emerald-500/30"
                          : "text-slate-300 bg-surface-hover hover:bg-slate-700 ring-1 ring-inset ring-border"
                      }`}
                    >
                      {s === "loading" ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : s === "done" ? (
                        <Check className="h-3.5 w-3.5" strokeWidth={2.5} />
                      ) : (
                        <Download className="h-3.5 w-3.5" />
                      )}
                      {s === "loading" ? "Fetching" : s === "done" ? "Downloaded" : "Download"}
                    </button>
                  </td>
                </tr>
              );
            })}
            {list.length === 0 && (
              <tr>
                <td colSpan={7} className="px-6 py-12 text-center text-[13px] text-slate-500">
                  No documents match your filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
