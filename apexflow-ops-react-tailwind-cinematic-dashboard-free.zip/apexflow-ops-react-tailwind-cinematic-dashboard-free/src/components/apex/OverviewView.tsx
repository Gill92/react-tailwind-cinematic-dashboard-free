import { useMemo } from "react";
import { KpiCard } from "./KpiCard";
import {
  activityFeed,
  sparkCosts,
  sparkPackages,
  sparkSavings,
  sparkUtilization,
  workPackages,
  STATUS_LABELS,
  type PackageStatus,
} from "@/lib/mockData";
import { useApp } from "./context";

const stageOrder: PackageStatus[] = ["scope", "in-progress", "verification", "complete"];
const stageColors: Record<PackageStatus, string> = {
  scope: "bg-slate-500",
  "in-progress": "bg-amber-500",
  verification: "bg-sky-500",
  complete: "bg-emerald-500",
};

export function OverviewView() {
  const { viewMode } = useApp();
  const visible = useMemo(
    () => (viewMode === "client" ? workPackages.filter((p) => p.clientVisible) : workPackages),
    [viewMode],
  );

  const stageCounts = useMemo(() => {
    const c = { scope: 0, "in-progress": 0, verification: 0, complete: 0 } as Record<PackageStatus, number>;
    visible.forEach((p) => (c[p.status] += 1));
    return c;
  }, [visible]);
  const total = visible.length;

  return (
    <div className="space-y-8">
      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-5">
        <KpiCard
          label="Total Active Packages"
          value={String(total)}
          subtitle="Across 3 active sites"
          delta="+3 this month"
          sparkData={sparkPackages}
        />
        <KpiCard
          label="Resource Utilization"
          value="87.4%"
          subtitle="Weighted across field crews"
          delta="+2.1%"
          sparkData={sparkUtilization}
          sparkColor="#f59e0b"
        />
        {viewMode === "operator" ? (
          <>
            <KpiCard
              label="Total Costs Tracked"
              value="$4.82M"
              subtitle="FY2026 tracked spend"
              delta="+8.4%"
              deltaPositive={false}
              sparkData={sparkCosts}
              sparkColor="#f59e0b"
            />
            <KpiCard
              label="Variance Savings"
              value="$318K"
              subtitle="Under-budget recovery"
              delta="+$26K MoM"
              sparkData={sparkSavings}
              accentValueColor="#10b981"
            />
          </>
        ) : (
          <>
            <KpiCard
              label="Your Active Packages"
              value={String(visible.filter((p) => p.status !== "complete").length)}
              subtitle="Assigned to your portfolio"
              delta="+2 this month"
              sparkData={sparkPackages}
            />
            <KpiCard
              label="Overall Completion"
              value={`${Math.round(visible.reduce((s, p) => s + p.progress, 0) / (visible.length || 1))}%`}
              subtitle="Weighted portfolio progress"
              delta="+4.2%"
              sparkData={sparkUtilization}
              accentValueColor="#10b981"
            />
          </>
        )}
      </div>

      {/* Second row */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        {/* Portfolio Health */}
        <div className="lg:col-span-3 rounded-xl bg-surface border border-border p-6">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
                Portfolio Health
              </h3>
              <p className="mt-1 text-[12.5px] text-slate-400">
                Distribution of {total} packages across pipeline stages
              </p>
            </div>
            <div className="text-[11px] uppercase tracking-widest text-slate-500 font-medium">
              Live
            </div>
          </div>

          {/* Stacked bar */}
          <div className="mt-6 h-2.5 w-full rounded-full overflow-hidden flex bg-surface-hover">
            {stageOrder.map((s) => {
              const pct = total ? (stageCounts[s] / total) * 100 : 0;
              return (
                <div
                  key={s}
                  className={`${stageColors[s]} transition-all duration-500`}
                  style={{ width: `${pct}%` }}
                />
              );
            })}
          </div>

          {/* Legend rows */}
          <div className="mt-6 space-y-3">
            {stageOrder.map((s) => {
              const count = stageCounts[s];
              const pct = total ? (count / total) * 100 : 0;
              return (
                <div key={s} className="flex items-center gap-3">
                  <span className={`h-2 w-2 rounded-full ${stageColors[s]}`} />
                  <span className="text-[13px] text-slate-300 flex-1">{STATUS_LABELS[s]}</span>
                  <span className="text-[13px] tabular text-slate-400 w-10 text-right">{count}</span>
                  <span className="text-[12px] tabular text-slate-500 w-14 text-right">
                    {pct.toFixed(0)}%
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Activity Feed */}
        <div className="lg:col-span-2 rounded-xl bg-surface border border-border p-6">
          <div className="flex items-center justify-between">
            <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
              Recent Activity
            </h3>
            <button className="text-[11.5px] font-medium text-slate-400 hover:text-slate-100 transition-colors">
              View all
            </button>
          </div>
          <ul className="mt-5 space-y-4">
            {activityFeed.map((a) => {
              const dotColor =
                a.tone === "positive"
                  ? "bg-emerald-500"
                  : a.tone === "critical"
                    ? "bg-red-500"
                    : a.tone === "pending"
                      ? "bg-amber-500"
                      : "bg-slate-500";
              return (
                <li key={a.id} className="flex gap-3">
                  <span className={`mt-1.5 h-2 w-2 shrink-0 rounded-full ${dotColor}`} />
                  <div className="min-w-0 flex-1">
                    <p className="text-[13px] text-slate-200 leading-snug">{a.message}</p>
                    <p className="mt-0.5 text-[11.5px] text-slate-500">{a.time}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </div>
  );
}
