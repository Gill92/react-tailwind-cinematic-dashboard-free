import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Legend,
  Line,
  LineChart,
  Pie,
  PieChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  budgetVsActual,
  costCategoryBreakdown,
  siteUtilization,
  wastageTimeline,
} from "@/lib/mockData";

const CAT_COLORS = ["#10b981", "#f59e0b", "#38bdf8", "#a78bfa"];

const tooltipStyle = {
  backgroundColor: "#0f172a",
  border: "1px solid #1e293b",
  borderRadius: "8px",
  fontSize: "12px",
  color: "#f8fafc",
};

function ProgressRing({ percent }: { percent: number }) {
  const size = 180;
  const stroke = 14;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (percent / 100) * c;
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#1e293b" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke="#10b981"
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={c}
          strokeDashoffset={off}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 800ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 grid place-items-center">
        <div className="text-center">
          <div className="text-[30px] font-semibold tracking-tight tabular text-slate-100">
            {percent}%
          </div>
          <div className="text-[10.5px] uppercase tracking-widest text-slate-500 mt-1">
            Achieved
          </div>
        </div>
      </div>
    </div>
  );
}

export function AnalyticsView() {
  const totalSavings = 340;
  const targetSavings = 500;
  const pct = Math.round((totalSavings / targetSavings) * 100);

  return (
    <div className="space-y-5">
      {/* Row 1 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-xl bg-surface border border-border p-6">
          <div>
            <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
              Cost Savings Achieved
            </h3>
            <p className="mt-1 text-[12.5px] text-slate-400">
              ${totalSavings}K of ${targetSavings}K FY26 target
            </p>
          </div>
          <div className="mt-6 flex items-center gap-8">
            <ProgressRing percent={pct} />
            <div className="space-y-3 flex-1">
              <LegendRow color="#10b981" label="Achieved" value={`$${totalSavings}K`} />
              <LegendRow color="#1e293b" label="Remaining" value={`$${targetSavings - totalSavings}K`} />
              <div className="mt-4 pt-4 border-t border-border">
                <div className="text-[11px] uppercase tracking-widest text-slate-500 font-medium">
                  Best Performing Site
                </div>
                <div className="mt-1 text-[14px] text-slate-100 font-medium">
                  Rotterdam Refinery
                </div>
                <div className="text-[12px] text-emerald-400">+$142K variance recovery</div>
              </div>
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-surface border border-border p-6">
          <div className="flex items-start justify-between">
            <div>
              <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
                Wastage Reduction
              </h3>
              <p className="mt-1 text-[12.5px] text-slate-400">
                Rolling monthly wastage as % of throughput
              </p>
            </div>
            <span className="inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-[11px] font-medium text-emerald-400 bg-emerald-500/10 ring-1 ring-inset ring-emerald-500/20">
              −56% vs Sep
            </span>
          </div>
          <div className="mt-4 h-[220px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={wastageTimeline} margin={{ left: -10, right: 8, top: 8, bottom: 0 }}>
                <CartesianGrid stroke="#1e293b" strokeDasharray="3 4" vertical={false} />
                <XAxis dataKey="month" stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} unit="%" />
                <Tooltip contentStyle={tooltipStyle} cursor={{ stroke: "#334155" }} />
                <Line
                  type="monotone"
                  dataKey="value"
                  stroke="#10b981"
                  strokeWidth={2.25}
                  dot={{ fill: "#10b981", r: 3 }}
                  activeDot={{ r: 5 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Row 2 - bar */}
      <div className="rounded-xl bg-surface border border-border p-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
              Budgeted vs. Actual Cost
            </h3>
            <p className="mt-1 text-[12.5px] text-slate-400">
              Per active work package, values in $K
            </p>
          </div>
          <div className="flex items-center gap-4 text-[11.5px]">
            <LegendDot color="#334155" label="Budget" />
            <LegendDot color="#10b981" label="Actual" />
          </div>
        </div>
        <div className="mt-6 h-[280px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={budgetVsActual} margin={{ left: -10, right: 8, top: 8, bottom: 0 }}>
              <CartesianGrid stroke="#1e293b" strokeDasharray="3 4" vertical={false} />
              <XAxis dataKey="pkg" stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} />
              <YAxis stroke="#64748b" fontSize={11} tickLine={false} axisLine={false} />
              <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(255,255,255,0.03)" }} />
              <Bar dataKey="Budget" fill="#334155" radius={[4, 4, 0, 0]} />
              <Bar dataKey="Actual" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Row 3 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="rounded-xl bg-surface border border-border p-6">
          <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
            Cost Distribution
          </h3>
          <p className="mt-1 text-[12.5px] text-slate-400">By category, FY26 rolling</p>
          <div className="mt-4 flex items-center gap-6">
            <div className="w-[200px] h-[200px] shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={costCategoryBreakdown}
                    dataKey="value"
                    innerRadius={55}
                    outerRadius={90}
                    paddingAngle={3}
                    stroke="none"
                  >
                    {costCategoryBreakdown.map((_, i) => (
                      <Cell key={i} fill={CAT_COLORS[i % CAT_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1 space-y-3">
              {costCategoryBreakdown.map((c, i) => (
                <LegendRow
                  key={c.name}
                  color={CAT_COLORS[i]}
                  label={c.name}
                  value={`${c.value}%`}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="rounded-xl bg-surface border border-border p-6">
          <h3 className="text-[16px] font-semibold tracking-tight text-slate-100">
            Utilization by Site
          </h3>
          <p className="mt-1 text-[12.5px] text-slate-400">Crew & equipment utilization</p>
          <div className="mt-6 space-y-5">
            {siteUtilization.map((s) => (
              <div key={s.site}>
                <div className="flex items-center justify-between text-[13px]">
                  <span className="text-slate-200 font-medium">{s.site}</span>
                  <span className="tabular text-slate-300">{s.value}%</span>
                </div>
                <div className="mt-2 h-2 rounded-full bg-surface-hover overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400"
                    style={{ width: `${s.value}%` }}
                  />
                </div>
              </div>
            ))}
            <div className="pt-4 border-t border-border">
              <div className="text-[11px] uppercase tracking-widest text-slate-500 font-medium">
                Fleet-wide Utilization
              </div>
              <div className="mt-1 text-[24px] tabular font-semibold text-slate-100 tracking-tight">
                87.4%
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function LegendRow({ color, label, value }: { color: string; label: string; value: string }) {
  return (
    <div className="flex items-center gap-3">
      <span className="h-2.5 w-2.5 rounded-sm" style={{ background: color }} />
      <span className="text-[13px] text-slate-300 flex-1">{label}</span>
      <span className="text-[13px] tabular text-slate-100 font-medium">{value}</span>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5 text-slate-400">
      <span className="h-2 w-2 rounded-full" style={{ background: color }} /> {label}
    </span>
  );
}

/* Placeholder for Legend import unused warning avoidance */
export const _unusedLegend = Legend;
