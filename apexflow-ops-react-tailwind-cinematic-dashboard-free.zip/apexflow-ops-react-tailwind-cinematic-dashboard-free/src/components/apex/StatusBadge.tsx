import { Check, Clock, Eye } from "lucide-react";

type DocStatus = "Approved" | "Pending" | "Under Review";

export function StatusBadge({ status }: { status: DocStatus }) {
  const map = {
    Approved: {
      cls: "text-emerald-400 bg-emerald-500/10 ring-emerald-500/20",
      Icon: Check,
    },
    Pending: {
      cls: "text-amber-400 bg-amber-500/10 ring-amber-500/20",
      Icon: Clock,
    },
    "Under Review": {
      cls: "text-slate-300 bg-slate-500/10 ring-slate-500/20",
      Icon: Eye,
    },
  } as const;
  const { cls, Icon } = map[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${cls}`}
    >
      <Icon className="h-3 w-3" strokeWidth={2.5} />
      {status}
    </span>
  );
}
