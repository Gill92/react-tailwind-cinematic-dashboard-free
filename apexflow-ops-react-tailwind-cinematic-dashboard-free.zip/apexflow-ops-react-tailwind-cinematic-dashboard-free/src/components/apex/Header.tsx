import { ChevronDown } from "lucide-react";
import { useApp } from "./context";
import { ViewModeSwitcher } from "./ViewModeSwitcher";

const titles: Record<string, { title: string; subtitle: string }> = {
  overview: { title: "Operations Overview", subtitle: "Real-time portfolio health" },
  workpackages: { title: "Active Work Packages", subtitle: "Pipeline & field execution" },
  analytics: { title: "Cost & Optimization Analytics", subtitle: "Variance, wastage, and utilization" },
  vault: { title: "Document Vault", subtitle: "Compliance, specifications & invoices" },
};

export function Header() {
  const { view, viewMode } = useApp();
  const meta = titles[view] ?? titles.overview;

  const persona =
    viewMode === "operator"
      ? { name: "Marcus Reyes", role: "Program Director", initials: "MR" }
      : { name: "Elena Voss", role: "PetroGen NV", initials: "EV" };

  return (
    <header className="sticky top-0 z-30 h-[72px] bg-surface/95 backdrop-blur border-b border-border">
      <div className="h-full px-8 flex items-center gap-6">
        <div className="min-w-0 flex-1">
          <div className="text-[11px] font-medium uppercase tracking-[0.14em] text-slate-500">
            ApexOps / {meta.title}
          </div>
          <div className="mt-0.5 text-[14px] text-slate-400 truncate">{meta.subtitle}</div>
        </div>

        <div className="hidden md:block">
          <ViewModeSwitcher />
        </div>

        <div className="flex items-center gap-3 pl-6 border-l border-border">
          <div className="h-9 w-9 rounded-full bg-emerald-500 grid place-items-center text-[12px] font-semibold text-emerald-950 ring-1 ring-emerald-400/60">
            {persona.initials}
          </div>
          <div className="hidden sm:block leading-tight">
            <div className="text-[13px] font-medium text-slate-100">{persona.name}</div>
            <div className="text-[11.5px] text-slate-500">{persona.role}</div>
          </div>
          <ChevronDown className="h-4 w-4 text-slate-500" />
        </div>
      </div>
    </header>
  );
}
