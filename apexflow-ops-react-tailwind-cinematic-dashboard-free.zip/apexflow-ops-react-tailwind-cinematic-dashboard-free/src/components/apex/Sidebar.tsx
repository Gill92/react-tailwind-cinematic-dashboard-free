import { useState } from "react";
import {
  Gauge,
  ListChecks,
  TrendingUp,
  FolderLock,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { useApp, type ViewKey } from "./context";

interface NavItem {
  key: ViewKey;
  label: string;
  icon: typeof Gauge;
}

const items: NavItem[] = [
  { key: "overview", label: "Operations Overview", icon: Gauge },
  { key: "workpackages", label: "Active Work Packages", icon: ListChecks },
  { key: "analytics", label: "Cost & Optimization Analytics", icon: TrendingUp },
  { key: "vault", label: "Document Vault", icon: FolderLock },
];

export function Sidebar() {
  const { view, setView, viewMode } = useApp();
  const [collapsed, setCollapsed] = useState(false);
  const w = collapsed ? "w-[72px]" : "w-[260px]";

  return (
    <aside
      className={`${w} shrink-0 h-screen sticky top-0 bg-surface border-r border-border flex flex-col transition-all duration-300`}
    >
      {/* Brand */}
      <div className="h-[72px] px-5 flex items-center gap-3 border-b border-border">
        <div className="h-9 w-9 shrink-0 grid place-items-center rounded-lg bg-emerald-500/15 ring-1 ring-emerald-500/30">
          <svg viewBox="0 0 24 24" className="h-5 w-5 text-emerald-400" fill="none" stroke="currentColor" strokeWidth="2.2">
            <path d="M12 2 L22 8 V16 L12 22 L2 16 V8 Z" strokeLinejoin="round" />
            <path d="M12 8 L16 10.5 V13.5 L12 16 L8 13.5 V10.5 Z" strokeLinejoin="round" />
          </svg>
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="text-[15px] font-semibold tracking-tight text-slate-50">ApexOps</div>
            <div className="text-[10.5px] font-medium uppercase tracking-widest text-slate-500">
              Ops Control
            </div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-5 space-y-1">
        {items.map((item) => {
          const Icon = item.icon;
          const active = view === item.key;
          const restricted = viewMode === "client" && item.key === "analytics";
          if (restricted) {
            return (
              <div
                key={item.key}
                title="Restricted in Client mode"
                className={`relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13.5px] font-medium text-slate-600 cursor-not-allowed select-none`}
              >
                <Icon className="h-[18px] w-[18px] shrink-0" strokeWidth={1.75} />
                {!collapsed && <span className="truncate">{item.label}</span>}
                {!collapsed && (
                  <span className="ml-auto text-[10px] uppercase tracking-widest text-slate-600">
                    Locked
                  </span>
                )}
              </div>
            );
          }
          return (
            <button
              key={item.key}
              onClick={() => setView(item.key)}
              className={`relative w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13.5px] font-medium transition-all duration-200 ${
                active
                  ? "bg-surface-hover text-slate-50"
                  : "text-slate-400 hover:text-slate-100 hover:bg-surface-hover/60"
              }`}
            >
              {active && (
                <span className="absolute left-0 top-2 bottom-2 w-[3px] rounded-r-full bg-emerald-500" />
              )}
              <Icon
                className={`h-[18px] w-[18px] shrink-0 ${active ? "text-emerald-400" : ""}`}
                strokeWidth={1.75}
              />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-3 border-t border-border space-y-2">
        <button
          onClick={() => setCollapsed((c) => !c)}
          className="w-full flex items-center gap-2 rounded-lg px-3 py-2 text-[12px] font-medium text-slate-400 hover:text-slate-100 hover:bg-surface-hover transition-all"
        >
          {collapsed ? <ChevronsRight className="h-4 w-4" /> : <ChevronsLeft className="h-4 w-4" />}
          {!collapsed && <span>Collapse</span>}
        </button>
        {!collapsed && (
          <div className="px-3 py-2">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10.5px] uppercase tracking-widest text-slate-500 font-medium">
                ApexOps v2.4 — Enterprise
              </span>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}
