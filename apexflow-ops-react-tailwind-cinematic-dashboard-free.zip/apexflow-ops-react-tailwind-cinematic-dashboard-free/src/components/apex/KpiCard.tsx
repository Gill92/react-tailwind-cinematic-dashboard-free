import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import { Sparkline } from "./Sparkline";

interface Props {
  label: string;
  value: string;
  subtitle: string;
  delta?: string;
  deltaPositive?: boolean;
  sparkData: number[];
  sparkColor?: string;
  accentValueColor?: string;
}

export function KpiCard({
  label,
  value,
  subtitle,
  delta,
  deltaPositive = true,
  sparkData,
  sparkColor = "#10b981",
  accentValueColor,
}: Props) {
  const DeltaIcon = deltaPositive ? ArrowUpRight : ArrowDownRight;
  return (
    <div className="group rounded-xl bg-surface border border-border p-6 transition-all duration-200 hover:border-slate-700 hover:shadow-lg hover:shadow-black/20">
      <div className="flex items-start justify-between">
        <div className="text-[11px] font-medium uppercase tracking-[0.14em] text-slate-500">
          {label}
        </div>
        {delta && (
          <span
            className={`inline-flex items-center gap-1 rounded-lg px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset ${
              deltaPositive
                ? "text-emerald-400 bg-emerald-500/10 ring-emerald-500/20"
                : "text-amber-400 bg-amber-500/10 ring-amber-500/20"
            }`}
          >
            <DeltaIcon className="h-3 w-3" strokeWidth={2.5} />
            {delta}
          </span>
        )}
      </div>
      <div
        className="mt-4 text-[30px] font-semibold tracking-tight tabular leading-none"
        style={accentValueColor ? { color: accentValueColor } : undefined}
      >
        {value}
      </div>
      <div className="mt-2 text-[12.5px] text-slate-400">{subtitle}</div>
      <div className="mt-5 -mx-1">
        <Sparkline data={sparkData} color={sparkColor} />
      </div>
    </div>
  );
}
