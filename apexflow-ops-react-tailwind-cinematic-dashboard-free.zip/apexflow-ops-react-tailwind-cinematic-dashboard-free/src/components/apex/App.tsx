import { useEffect, useMemo, useState } from "react";
import { AppContext, type ViewKey, type ViewMode } from "./context";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { OverviewView } from "./OverviewView";
import { WorkPackagesView } from "./WorkPackagesView";
import { AnalyticsView } from "./AnalyticsView";
import { VaultView } from "./VaultView";

const validViews: ViewKey[] = ["overview", "workpackages", "analytics", "vault"];
const validModes: ViewMode[] = ["operator", "client"];

function parseHash(): { view?: ViewKey; mode?: ViewMode } {
  if (typeof window === "undefined") return {};
  const hash = window.location.hash.replace(/^#/, "");
  const params = new URLSearchParams(hash);
  const v = params.get("view") as ViewKey | null;
  const m = params.get("mode") as ViewMode | null;
  return {
    view: v && validViews.includes(v) ? v : undefined,
    mode: m && validModes.includes(m) ? m : undefined,
  };
}

export function ApexApp() {
  const [viewMode, setViewMode] = useState<ViewMode>("operator");
  const [view, setView] = useState<ViewKey>("overview");

  // Restore from URL hash on mount (so refresh keeps the tab).
  useEffect(() => {
    const { view: v, mode: m } = parseHash();
    if (v) setView(v);
    if (m) setViewMode(m);
    const onHash = () => {
      const parsed = parseHash();
      if (parsed.view) setView(parsed.view);
      if (parsed.mode) setViewMode(parsed.mode);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  // Sync state → URL hash.
  useEffect(() => {
    if (typeof window === "undefined") return;
    const next = `#view=${view}&mode=${viewMode}`;
    if (window.location.hash !== next) {
      window.history.replaceState(null, "", next);
    }
  }, [view, viewMode]);

  // In client mode, analytics is locked — bounce back to overview if user was there.
  useEffect(() => {
    if (viewMode === "client" && view === "analytics") setView("overview");
  }, [viewMode, view]);

  const ctx = useMemo(() => ({ viewMode, setViewMode, view, setView }), [viewMode, view]);

  return (
    <AppContext.Provider value={ctx}>
      <div className="min-h-screen w-full bg-background text-foreground flex">
        <Sidebar />
        <div className="flex-1 min-w-0 flex flex-col">
          <Header />
          <main className="flex-1 p-8">
            <div
              key={`${view}-${viewMode}`}
              className="animate-in fade-in duration-300"
            >
              {view === "overview" && <OverviewView />}
              {view === "workpackages" && <WorkPackagesView />}
              {view === "analytics" && <AnalyticsView />}
              {view === "vault" && <VaultView />}
            </div>
          </main>
        </div>
      </div>
    </AppContext.Provider>
  );
}
