export type PackageStatus =
  | "scope"
  | "in-progress"
  | "verification"
  | "complete";

export type Priority = "on-track" | "watch" | "at-risk";

export interface WorkPackage {
  id: string;
  code: string;
  title: string;
  site: string;
  clientId: string;
  clientName: string;
  clientVisible: boolean;
  lead: string;
  leadInitials: string;
  progress: number;
  budget: number;
  actualCost: number;
  status: PackageStatus;
  priority: Priority;
  dueDate: string;
}

export const STATUS_LABELS: Record<PackageStatus, string> = {
  scope: "Scope Definition",
  "in-progress": "In Progress",
  verification: "Cost / Field Verification",
  complete: "Sign-Off Complete",
};

export const workPackages: WorkPackage[] = [
  {
    id: "wp-104",
    code: "#104",
    title: "Turnaround Structural Assembly",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Anika Sørensen",
    leadInitials: "AS",
    progress: 62,
    budget: 150000,
    actualCost: 142000,
    status: "in-progress",
    priority: "on-track",
    dueDate: "Mar 12",
  },
  {
    id: "wp-098",
    code: "#098",
    title: "Piping Rework & Pressure Test",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Devon Achterberg",
    leadInitials: "DA",
    progress: 78,
    budget: 210000,
    actualCost: 224500,
    status: "verification",
    priority: "at-risk",
    dueDate: "Feb 28",
  },
  {
    id: "wp-112",
    code: "#112",
    title: "Instrumentation Calibration Sweep",
    site: "Antwerp Terminal",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Priya Ramanathan",
    leadInitials: "PR",
    progress: 100,
    budget: 88000,
    actualCost: 81200,
    status: "complete",
    priority: "on-track",
    dueDate: "Feb 20",
  },
  {
    id: "wp-087",
    code: "#087",
    title: "Scaffold Access Compliance Review",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Marcus Reyes",
    leadInitials: "MR",
    progress: 34,
    budget: 62000,
    actualCost: 21400,
    status: "scope",
    priority: "watch",
    dueDate: "Apr 04",
  },
  {
    id: "wp-121",
    code: "#121",
    title: "Heat Exchanger Bundle Replacement",
    site: "Antwerp Terminal",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Anika Sørensen",
    leadInitials: "AS",
    progress: 48,
    budget: 340000,
    actualCost: 312000,
    status: "in-progress",
    priority: "on-track",
    dueDate: "Mar 22",
  },
  {
    id: "wp-076",
    code: "#076",
    title: "Electrical Isolation Certification",
    site: "Bergen LNG",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Jonas Weller",
    leadInitials: "JW",
    progress: 100,
    budget: 47000,
    actualCost: 44800,
    status: "complete",
    priority: "on-track",
    dueDate: "Feb 14",
  },
  {
    id: "wp-133",
    code: "#133",
    title: "Flare Stack Integrity Inspection",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: false,
    lead: "Devon Achterberg",
    leadInitials: "DA",
    progress: 12,
    budget: 92000,
    actualCost: 8400,
    status: "scope",
    priority: "on-track",
    dueDate: "Apr 18",
  },
  {
    id: "wp-141",
    code: "#141",
    title: "Cathodic Protection Retrofit",
    site: "Bergen LNG",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Priya Ramanathan",
    leadInitials: "PR",
    progress: 55,
    budget: 128000,
    actualCost: 119200,
    status: "in-progress",
    priority: "on-track",
    dueDate: "Mar 30",
  },
  {
    id: "wp-115",
    code: "#115",
    title: "Column Tray Refurbishment",
    site: "Antwerp Terminal",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: false,
    lead: "Marcus Reyes",
    leadInitials: "MR",
    progress: 71,
    budget: 195000,
    actualCost: 188700,
    status: "verification",
    priority: "watch",
    dueDate: "Mar 08",
  },
  {
    id: "wp-152",
    code: "#152",
    title: "Fireproofing Coat Application",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Jonas Weller",
    leadInitials: "JW",
    progress: 22,
    budget: 74000,
    actualCost: 15100,
    status: "scope",
    priority: "on-track",
    dueDate: "Apr 26",
  },
  {
    id: "wp-129",
    code: "#129",
    title: "Compressor Overhaul Sequence",
    site: "Bergen LNG",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Anika Sørensen",
    leadInitials: "AS",
    progress: 44,
    budget: 410000,
    actualCost: 388400,
    status: "in-progress",
    priority: "on-track",
    dueDate: "Apr 02",
  },
  {
    id: "wp-091",
    code: "#091",
    title: "Emergency Shutdown Loop Validation",
    site: "Antwerp Terminal",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Devon Achterberg",
    leadInitials: "DA",
    progress: 100,
    budget: 68000,
    actualCost: 64100,
    status: "complete",
    priority: "on-track",
    dueDate: "Feb 08",
  },
  {
    id: "wp-147",
    code: "#147",
    title: "Nitrogen Purge & Line Break",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Priya Ramanathan",
    leadInitials: "PR",
    progress: 88,
    budget: 55000,
    actualCost: 53200,
    status: "verification",
    priority: "on-track",
    dueDate: "Mar 05",
  },
  {
    id: "wp-158",
    code: "#158",
    title: "Rotating Equipment Vibration Audit",
    site: "Bergen LNG",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: false,
    lead: "Marcus Reyes",
    leadInitials: "MR",
    progress: 9,
    budget: 82000,
    actualCost: 5600,
    status: "scope",
    priority: "on-track",
    dueDate: "May 02",
  },
  {
    id: "wp-102",
    code: "#102",
    title: "Tank Bottom NDT Sweep",
    site: "Antwerp Terminal",
    clientId: "northsea",
    clientName: "NorthSea Midstream",
    clientVisible: true,
    lead: "Jonas Weller",
    leadInitials: "JW",
    progress: 66,
    budget: 118000,
    actualCost: 114900,
    status: "verification",
    priority: "watch",
    dueDate: "Mar 14",
  },
  {
    id: "wp-119",
    code: "#119",
    title: "Relief Valve Bench Certification",
    site: "Rotterdam Refinery",
    clientId: "petrogen",
    clientName: "PetroGen NV",
    clientVisible: true,
    lead: "Anika Sørensen",
    leadInitials: "AS",
    progress: 100,
    budget: 39000,
    actualCost: 36200,
    status: "complete",
    priority: "on-track",
    dueDate: "Feb 24",
  },
];

export interface ActivityItem {
  id: string;
  message: string;
  time: string;
  tone: "positive" | "pending" | "critical" | "neutral";
}

export const activityFeed: ActivityItem[] = [
  { id: "a1", message: "Package #112 moved to Sign-Off Complete", time: "2h ago", tone: "positive" },
  { id: "a2", message: "Cost variance flagged on Package #098 (+$14.5K)", time: "5h ago", tone: "critical" },
  { id: "a3", message: "Compliance sign-off uploaded for #076", time: "8h ago", tone: "positive" },
  { id: "a4", message: "Package #087 scope revised by M. Reyes", time: "11h ago", tone: "pending" },
  { id: "a5", message: "New work package #158 created — Bergen LNG", time: "1d ago", tone: "neutral" },
  { id: "a6", message: "Field verification started on Package #147", time: "1d ago", tone: "pending" },
];

export interface DocumentRow {
  id: string;
  name: string;
  category: "Specifications" | "Compliance" | "Invoices";
  packageCode: string;
  uploaded: string;
  status: "Approved" | "Pending" | "Under Review";
  size: string;
  clientVisible: boolean;
}

export const documents: DocumentRow[] = [
  { id: "d1", name: "Structural Integrity Spec Rev.C.pdf", category: "Specifications", packageCode: "#104", uploaded: "Feb 12, 2026", status: "Approved", size: "4.2 MB", clientVisible: true },
  { id: "d2", name: "Compliance Sign-Off — Package #104.pdf", category: "Compliance", packageCode: "#104", uploaded: "Feb 18, 2026", status: "Approved", size: "1.1 MB", clientVisible: true },
  { id: "d3", name: "Invoice #INV-2291 — Field Verification.pdf", category: "Invoices", packageCode: "#098", uploaded: "Feb 21, 2026", status: "Pending", size: "820 KB", clientVisible: false },
  { id: "d4", name: "Isolation Certificate — Package #076.pdf", category: "Compliance", packageCode: "#076", uploaded: "Feb 14, 2026", status: "Approved", size: "612 KB", clientVisible: true },
  { id: "d5", name: "Pressure Test Report — Package #098.pdf", category: "Specifications", packageCode: "#098", uploaded: "Feb 20, 2026", status: "Under Review", size: "3.8 MB", clientVisible: true },
  { id: "d6", name: "Heat Exchanger Torque Log.pdf", category: "Specifications", packageCode: "#121", uploaded: "Feb 23, 2026", status: "Pending", size: "2.4 MB", clientVisible: true },
  { id: "d7", name: "Invoice #INV-2304 — Materials Q1.pdf", category: "Invoices", packageCode: "#121", uploaded: "Feb 25, 2026", status: "Approved", size: "740 KB", clientVisible: false },
  { id: "d8", name: "Scaffold Erection Method Statement.pdf", category: "Specifications", packageCode: "#087", uploaded: "Feb 09, 2026", status: "Under Review", size: "1.9 MB", clientVisible: true },
  { id: "d9", name: "Cathodic Protection Survey.pdf", category: "Compliance", packageCode: "#141", uploaded: "Feb 27, 2026", status: "Pending", size: "5.1 MB", clientVisible: true },
  { id: "d10", name: "Invoice #INV-2318 — Labor Overrun.pdf", category: "Invoices", packageCode: "#098", uploaded: "Feb 28, 2026", status: "Under Review", size: "690 KB", clientVisible: false },
  { id: "d11", name: "Instrument Loop Datasheet Rev.B.pdf", category: "Specifications", packageCode: "#112", uploaded: "Feb 15, 2026", status: "Approved", size: "2.2 MB", clientVisible: true },
  { id: "d12", name: "Relief Valve Bench Cert #119.pdf", category: "Compliance", packageCode: "#119", uploaded: "Feb 24, 2026", status: "Approved", size: "480 KB", clientVisible: true },
  { id: "d13", name: "Compressor Overhaul Procedure.pdf", category: "Specifications", packageCode: "#129", uploaded: "Feb 26, 2026", status: "Pending", size: "6.3 MB", clientVisible: true },
  { id: "d14", name: "Invoice #INV-2277 — Compliance Audit.pdf", category: "Invoices", packageCode: "#076", uploaded: "Feb 16, 2026", status: "Approved", size: "560 KB", clientVisible: false },
];

/* Sparkline datasets */
export const sparkPackages = [18, 20, 19, 21, 22, 21, 23, 24];
export const sparkUtilization = [72, 76, 74, 80, 83, 85, 86, 87];
export const sparkCosts = [3.1, 3.4, 3.6, 3.9, 4.1, 4.3, 4.6, 4.82];
export const sparkSavings = [140, 175, 190, 220, 245, 268, 292, 318];

export const budgetVsActual = [
  { pkg: "#104", Budget: 150, Actual: 142 },
  { pkg: "#098", Budget: 210, Actual: 224 },
  { pkg: "#121", Budget: 340, Actual: 312 },
  { pkg: "#141", Budget: 128, Actual: 119 },
  { pkg: "#129", Budget: 410, Actual: 388 },
  { pkg: "#147", Budget: 55, Actual: 53 },
];

export const costCategoryBreakdown = [
  { name: "Labor", value: 38 },
  { name: "Materials", value: 32 },
  { name: "Equipment", value: 18 },
  { name: "Compliance", value: 12 },
];

export const wastageTimeline = [
  { month: "Sep", value: 8.4 },
  { month: "Oct", value: 7.1 },
  { month: "Nov", value: 6.2 },
  { month: "Dec", value: 5.8 },
  { month: "Jan", value: 4.9 },
  { month: "Feb", value: 3.7 },
];

export const siteUtilization = [
  { site: "Rotterdam Refinery", value: 91 },
  { site: "Antwerp Terminal", value: 84 },
  { site: "Bergen LNG", value: 76 },
];
